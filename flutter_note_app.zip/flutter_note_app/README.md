# Notes App

This Application is Created Using Flutter.

![The example app running in Android](https://github.com/simformsolutions/flutter_note_app/blob/master/preview/preview.gif)

## Featues 

*  Save Note.
*  Dynamic Theame.
*  Share App Directly from Application.
*  Amazing Animation on FAB.

## Packages Used
*  [SQFlite]( https://pub.dev/packages/sqflite )
*  [Shared Preferances](https://pub.dev/packages/shared_preferences)
*  [Share]( https://pub.dev/packages/share )
